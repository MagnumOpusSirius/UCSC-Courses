close all; clear;clc;

%compute the least square solution for A, b in 3 different ways
%(i) Solve it by hand
%(ii) xhat_QR factorization
%(iii) xhat_normal=(ATA)^-1(ATb)
for k=5:8
    A=[1 1; 
       10^(-k) 0; 
       0 10^(-k)];
    %vpa(A)

    b=[-10^(-k);
        1+10^(-k);
        1-10^(-k)];
    fprintf("For k = %d\n",k);
    xhat_analytical=[1; -1]
    xhat_QR=A\b
    xhat_normal=(A'*A)\(A'*b)
end