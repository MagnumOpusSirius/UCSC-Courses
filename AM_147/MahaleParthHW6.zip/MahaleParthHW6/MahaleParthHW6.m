close all; clear; clc;

set(groot,'defaultAxesTickLabelInterpreter','latex');  
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

% generate datapoints
x_data = (-1:0.1:1)';
y_data = 1./(1 + 25*x_data.^2);

% plot datapoints
figure(1)
plot(x_data,y_data,'ko','LineWidth',2,'MarkerFaceColor','k')
xlabel('$x$','FontSize',30); ylabel('$y$','FontSize',30,'rotation',0); 
set(gca,'FontSize',30)
hold on 

% blocks of the coefficient matrix
for i=1:numel(x_data)-1
    X{i} =[x_data(i), 1; x_data(i+1), 1];
end
% set up and solve the linear system
A = blkdiag(X{:});%40x40 matrix
y =[y_data(1); repelem(y_data(2:end-1), 2); y_data(end)];%40x1 col vector [y0 y1 y1 y2...]
c = A\y;%40x1 col vector
% plot the computed spline interpolant
for i=1:numel(x_data)-1
    line_idx =i;
    % straight line segment as function handle
    f = @(x) c(line_idx)*x + c(line_idx+1);
    % plot the line segment
    fplot(f, [x_data(i), x_data(i+1)], '-r', 'Linewidth',2)
    hold on
end