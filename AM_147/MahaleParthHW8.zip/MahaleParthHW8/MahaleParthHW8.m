close all; clear; clc;

set(groot,'defaultAxesTickLabelInterpreter','latex');  
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

% data
t = (1:500)';
x = 2*sin(0.1*t) + 3*cos(0.01*t) + 4*sin(0.02*t);

noise = -ones(size(x)) + 2*rand(size(x));

x_noisy = x + noise;

figure(1)
plot(t,x,'-k','LineWidth',2)
hold on
plot(t,x_noisy,'-b','LineWidth',1)
hold on
set(gca,'FontSize',30)
xlabel('$t$','FontSize',35); ylabel('$x$','FontSize',35,'rotation',0)
axis tight

%% recover an estimate xhat for the original unknown signal x from x_noisy
Imat =eye(500);% 500 by 500 identity matrix with 1's on the main diag and 0 elsewhere 
D =diag(ones([499,1]),1); %ones() returns a 499 by 1 array of 1's ... diag() places the element of vector [499,1] above the main diagonal
D =D+(-1*Imat); 
D(end,:) = []; 
%Source for eye(n): https://www.mathworks.com/help/matlab/ref/eye.html#d124e427929

beta = [1; 10; 100];
 line_style = {'-','-','-'}; line_color = {'r','c','g'};
% 
 for j=1:length(beta)
%     
%     % least squares estimate via A\b
     A=cat(1,Imat,sqrt(beta(j))*D);
     b=cat(1,x_noisy, zeros([499,1]));
     xhat(:,j) = A \ b;
     plot(t,xhat(:,j),'color',line_color{j},'linestyle',line_style{j},'LineWidth',2)
     hold on
 end
 legend('$x_{\rm{true}}$','$x_{\rm{noisy}}$','$\beta = 1$','$\beta = 10$','$\beta = 100$')
 hold off
