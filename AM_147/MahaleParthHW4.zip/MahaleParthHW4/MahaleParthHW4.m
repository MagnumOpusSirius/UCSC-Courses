%we are updating the solution of Keplers equation in each iteration
close all; clear; clc;

hold on;

%50 random initial guesses between [0,1]
x_0=rand(50,1);
for j = 1:50
    %50 random initial guesses between [0,1]
    x_k = x_0(j);
    %k is used as the index to loop 20 times
    for k = 1:20
        %add an element x_k to end of array using fixed point recursion
        x_k = [x_k, 0.5 + 0.5 * sin(x_k(end))];
    end
    %plot 20 recursions of 50 initial guesses of x_k
    plot(0:20,x_k)
end
xlabel('Recursion Index k')
ylabel('x_k')
set(get(gca,'ylabel'),'rotation',0,'HorizontalAlignment','right')
title('Keplers Equation')
