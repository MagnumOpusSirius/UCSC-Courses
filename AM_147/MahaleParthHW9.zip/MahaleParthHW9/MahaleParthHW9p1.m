% Problem: Modeling virus spread (SIRD model) over time (t)
% N = total residential pop of county
% S(t) = sus individual, I(t)=infected individual, R(t)=Recovered,
% D(t)=dead
% Nonlinear ODE is:

clear;clc;

t1=0; 
t2=100; 
arr=[995 5 0 0];

% (a) using ode45 plot the time series for the variables

[t,func]=ode45(@SIRD_dynamics, [t1 t2], arr);
plot(t, func(:,1), '-b', t, func(:,2), '-r', t,func(:,3), '-g', t, func(:,4), '-k',LineWidth=1)
hold on;
xlabel('Time')
ylabel('y')
%legend('Sus', 'Infec', 'Rec', 'Dead')

% (b)

[time_rk, step]=FixedStepRK4(@SIRD_dynamics, [t1 t2], arr, 0.5);
plot(time_rk, step(:,1), 'bo', time_rk,step(:,2), 'ro', time_rk,step(:,3),'go', time_rk,step(:,4),'ko', LineWidth=1)

legend('Suspect','Infected','Recovered', 'Dead')
