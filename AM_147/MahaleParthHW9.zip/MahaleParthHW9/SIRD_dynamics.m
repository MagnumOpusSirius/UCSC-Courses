% specify the dynamics of virus spread for:
% infection rate beta=0.45
% recovery rate lambda=0.04
% mortality rate mu=0.01
% total population N = 1000

function dt= SIRD_dynamics(t,func)
    beta=0.45;
    lambd = 0.04;
    mu=0.01;
    N=1000;

    dt(1,:)=-(beta/N)*func(2)*func(1);
    dt(2,:)=(beta/N)*func(2)*func(1)-(lambd*func(2))-(mu*func(2));
    dt(3,:)=lambd*func(2);
    dt(4,:)=mu*func(2);
end