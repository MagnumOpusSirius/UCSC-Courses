function [t,y]= FixedStepRK4(ft, val, init, delt)

    y=init;
    t=val(1):delt:val(2);
    for i=1:length(t)-1

        i1=delt*ft(t(i),y);
        i2=delt*ft(t(i)+delt/2, y(i,:)'+i1/2);
        i3=delt*ft(t(i)+delt/2, y(i,:)'+i2/2);
        i4=delt*ft(t(i)+delt, y(i,:)'+i3);

        y(i+1,:)=y(i,:)' + (1/6)*(i1+(2*i2)+(2*i3)+i4);
    end
end



