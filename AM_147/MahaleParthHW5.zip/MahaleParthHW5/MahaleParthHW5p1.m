close all;clear; clc;

%find the rational function
%solve for Ax=b for vector x defined in p and q terms
%plot the rational curve

%for t=1
%Step 1:
    %p1+p2+p3/(1+q1+q2)=2
%Step 2:
    %p1+p2+p3-2-2q1-2q2=0
%So on so forth for the rest of the rows

A=[1 1 1 -2 -2;
   1 2 4 -10 -20; 
   1 3 9 -27 -81;
   1 4 16 4 16;
   1 5 25 20 100];

b=[2; 5; 9; -1; -4];

x=A\b;

%p1 = x(1);
%p2 = x(2);
%p3 = x(3);
%q1 = x(4);
%q2 = x(5);

p=@(t) (x(1)+ x(2)*t + x(3)*t.^2)/ (1+ x(4)*t +x(5)*t.^2);
fplot(p,[-6,6]);
xlabel('t');
ylabel('f(t)');
title('Computed Rational Curve');